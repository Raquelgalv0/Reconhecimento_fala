import { useState, useEffect, useRef, MouseEvent } from "react";
import {
  Message,
  WorkingMemory,
  MaterialGerado,
  SavedPlanning,
} from "./types";
import DashboardView from "./components/DashboardView";
import WorkingMemoryView from "./components/WorkingMemoryView";
import MaterialViewer from "./components/MaterialViewer";
import {
  Plus,
  Trash2,
  Send,
  Sparkles,
  BookOpen,
  ClipboardList,
  Eye,
  GraduationCap,
  MessageSquare,
  HelpCircle,
  ExternalLink,
  ChevronRight,
  RefreshCw,
  FolderOpen,
} from "lucide-react";

const INITIAL_MESSAGES: Message[] = [
  {
    id: "init-1",
    role: "assistant",
    content: `🌻 Oi, prof! Seja muito bem-vindo(a) ao EducaInclusiva!

Fico muito feliz por ter você aqui. 💙

Antes de começarmos, quero fazer um convite rapidinho: se você ainda não me acompanha no Instagram, passa lá para conhecer meu trabalho. Compartilho conteúdos sobre Inteligência Artificial aplicada à educação, dicas práticas para professores e novidades que podem facilitar seu dia a dia em sala de aula.

📲 Instagram: @raquelgalvao.ia

🔗 https://www.instagram.com/raquelgalvao.ia

Seu apoio faz toda a diferença e me incentiva a continuar criando agentes e ferramentas para educadores. 🥰

Agora vamos ao que interessa!

Vamos construir esse planejamento juntos.

📚 Qual é a disciplina da aula que vamos planejar?`,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  },
];

const DEFAULT_MEMORY: WorkingMemory = {
  disciplina: "Ainda não definida",
  ano: "Ainda não definido",
  tema: "Ainda não definido",
  objetivo: "Ainda não definido",
  perfisInclusivos: "Nenhum mapeado",
  recursos: "Ainda não definido",
};

const DEFAULT_MATERIAL: MaterialGerado = {
  type: "none",
  title: "",
  markdown: "",
};

export default function App() {
  const [savedPlannings, setSavedPlannings] = useState<SavedPlanning[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [workingMemory, setWorkingMemory] = useState<WorkingMemory>(DEFAULT_MEMORY);
  const [material, setMaterial] = useState<MaterialGerado>(DEFAULT_MATERIAL);
  const [suggestions, setSuggestions] = useState<string[]>([
    "Língua Portuguesa",
    "Matemática",
    "Ciências",
    "História",
    "Geografia",
  ]);

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [currentTab, setCurrentTab] = useState<"memory" | "document" | "dashboard">("memory");

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Load history from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem("educainclusiva_plannings");
      if (stored) {
        const parsed = JSON.parse(stored) as SavedPlanning[];
        setSavedPlannings(parsed);
        if (parsed.length > 0) {
          // Load the latest planning automatically
          const latest = parsed[0];
          setActiveId(latest.id);
          setMessages(latest.messages);
          setWorkingMemory(latest.workingMemory);
          setMaterial(latest.material);
        }
      }
    } catch (e) {
      console.error("Erro ao carregar do localStorage:", e);
    }
  }, []);

  // Save history to localStorage whenever savedPlannings changes
  const saveToStorage = (updated: SavedPlanning[]) => {
    localStorage.setItem("educainclusiva_plannings", JSON.stringify(updated));
    setSavedPlannings(updated);
  };

  // Scroll to chat bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // Create a new planning session
  const handleNewPlanning = () => {
    // Generate new ID
    const newId = "plan_" + Date.now();
    const newPlan: SavedPlanning = {
      id: newId,
      title: "Planejamento sem título",
      discipline: "Geral",
      createdAt: new Date().toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
      }),
      messages: INITIAL_MESSAGES,
      workingMemory: DEFAULT_MEMORY,
      material: DEFAULT_MATERIAL,
    };

    const updated = [newPlan, ...savedPlannings];
    saveToStorage(updated);
    setActiveId(newId);
    setMessages(INITIAL_MESSAGES);
    setWorkingMemory(DEFAULT_MEMORY);
    setMaterial(DEFAULT_MATERIAL);
    setSuggestions(["Língua Portuguesa", "Matemática", "Ciências", "História", "Geografia"]);
    setCurrentTab("memory");
    setErrorBanner(null);
  };

  // Select planning from history
  const handleSelectPlanning = (id: string) => {
    const selected = savedPlannings.find((p) => p.id === id);
    if (selected) {
      setActiveId(selected.id);
      setMessages(selected.messages);
      setWorkingMemory(selected.workingMemory);
      setMaterial(selected.material);

      // Dynamically derive some contextual quick suggestions if the chat is already finished or active
      if (selected.material.type !== "none") {
        setSuggestions([
          "Fazer outra adaptação",
          "Criar uma avaliação para este plano",
          "Gerar dashboard de acessibilidade",
        ]);
        setCurrentTab("document");
      } else {
        // Find suggestions from the last assistant message
        const lastAssistant = [...selected.messages]
          .reverse()
          .find((m) => m.role === "assistant");
        if (lastAssistant) {
          // Fallback context suggestions
          setSuggestions(["Sim, está ótimo!", "Preciso de adaptações", "Alterar disciplina"]);
        } else {
          setSuggestions(["Língua Portuguesa", "Matemática", "Ciências"]);
        }
        setCurrentTab("memory");
      }
      setErrorBanner(null);
    }
  };

  // Delete a planning session
  const handleDeletePlanning = (e: MouseEvent, id: string) => {
    e.stopPropagation();
    const filtered = savedPlannings.filter((p) => p.id !== id);
    saveToStorage(filtered);

    if (activeId === id) {
      if (filtered.length > 0) {
        handleSelectPlanning(filtered[0].id);
      } else {
        // Reset to empty state but with active initial
        setActiveId(null);
        setMessages(INITIAL_MESSAGES);
        setWorkingMemory(DEFAULT_MEMORY);
        setMaterial(DEFAULT_MATERIAL);
        setSuggestions(["Língua Portuguesa", "Matemática", "Ciências", "História", "Geografia"]);
        setCurrentTab("memory");
      }
    }
  };

  // Main chat message submission
  const sendMessage = async (text: string) => {
    if (!text.trim() || loading) return;

    setErrorBanner(null);
    const userMsg: Message = {
      id: "user_" + Date.now(),
      role: "user",
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      // API request to server endpoint
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Ocorreu um erro ao falar com o EducaInclusiva.");
      }

      const data = await response.json();

      const assistantMsg: Message = {
        id: "assistant_" + Date.now(),
        role: "assistant",
        content: data.chatResponse || "Peço desculpas, não consegui formular a resposta ideal.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      const finalMessages = [...newMessages, assistantMsg];
      setMessages(finalMessages);

      if (data.memoriaDeTrabalho) {
        setWorkingMemory(data.memoriaDeTrabalho);
      }

      if (data.materialGerado) {
        setMaterial(data.materialGerado);
        if (data.materialGerado.type !== "none") {
          // Switch to appropriate tab automatically on generation
          if (data.materialGerado.type === "dashboard") {
            setCurrentTab("dashboard");
          } else {
            setCurrentTab("document");
          }
        }
      }

      if (data.proximasSugestoes) {
        setSuggestions(data.proximasSugestoes);
      }

      // Sync active session inside the saved history list
      let currentId = activeId;
      let updatedPlannings = [...savedPlannings];

      if (!currentId) {
        // Create new session if none was saved/active
        currentId = "plan_" + Date.now();
        setActiveId(currentId);
        const newPlan: SavedPlanning = {
          id: currentId,
          title: data.memoriaDeTrabalho?.tema !== "Ainda não definido" 
            ? `Plano: ${data.memoriaDeTrabalho.tema}` 
            : `Planejamento de ${data.memoriaDeTrabalho?.disciplina || "Geral"}`,
          discipline: data.memoriaDeTrabalho?.disciplina || "Geral",
          createdAt: new Date().toLocaleDateString("pt-BR", {
            day: "2-digit",
            month: "short",
            hour: "2-digit",
            minute: "2-digit",
          }),
          messages: finalMessages,
          workingMemory: data.memoriaDeTrabalho || DEFAULT_MEMORY,
          material: data.materialGerado || DEFAULT_MATERIAL,
        };
        updatedPlannings = [newPlan, ...updatedPlannings];
      } else {
        // Update existing session
        updatedPlannings = updatedPlannings.map((p) => {
          if (p.id === currentId) {
            // Update title once we have a theme or subject
            let title = p.title;
            if (p.title === "Planejamento sem título" || p.title.startsWith("Planejamento de")) {
              if (data.memoriaDeTrabalho?.tema && data.memoriaDeTrabalho.tema !== "Ainda não definido") {
                title = `Plano: ${data.memoriaDeTrabalho.tema}`;
              } else if (data.memoriaDeTrabalho?.disciplina && data.memoriaDeTrabalho.disciplina !== "Ainda não definida") {
                title = `Planejamento de ${data.memoriaDeTrabalho.disciplina}`;
              }
            }
            return {
              ...p,
              title: title,
              discipline: data.memoriaDeTrabalho?.disciplina || p.discipline,
              messages: finalMessages,
              workingMemory: data.memoriaDeTrabalho || p.workingMemory,
              material: data.materialGerado || p.material,
            };
          }
          return p;
        });
      }

      saveToStorage(updatedPlannings);
    } catch (err: any) {
      console.error(err);
      setErrorBanner(err.message || "Erro de conexão com o servidor. Verifique os Secrets.");
    } finally {
      setLoading(false);
    }
  };

  // Helper when clicking quick suggested reply chips
  const handleSuggestionClick = (sug: string) => {
    sendMessage(sug);
  };

  // Fast starter template selection to kick off plans
  const handleLoadStarterTemplate = (discipline: string, grade: string, topic: string, profile: string) => {
    const starterPrompt = `Olá EducaInclusiva! Quero fazer um planejamento para a disciplina de ${discipline}, para o ${grade}, sobre o tema "${topic}", com adaptações específicas para ${profile}.`;
    sendMessage(starterPrompt);
  };

  // Handler for dashboard modifications from within child component
  const handleUpdateDashboardData = (updatedDataString: string) => {
    if (!activeId) return;

    const updatedMaterial = { ...material, dashboardData: updatedDataString };
    setMaterial(updatedMaterial);

    const updatedPlannings = savedPlannings.map((p) => {
      if (p.id === activeId) {
        return { ...p, material: updatedMaterial };
      }
      return p;
    });
    saveToStorage(updatedPlannings);
  };

  return (
    <div id="app-root" className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-indigo-100 antialiased text-gray-800">
      {/* Premium Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50 px-4 py-3.5 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 text-white p-2.5 rounded-xl shadow-md shadow-indigo-100 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-black tracking-tight text-gray-900 font-sans flex items-center gap-2">
                EducaInclusiva
                <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full font-bold">
                  Copiloto Pedagógico
                </span>
              </h1>
              <p className="text-xs text-gray-500 mt-0.5">
                Planejamento escolar e adaptação pedagógica com foco em inclusão
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            {/* Instagram link */}
            <a
              href="https://www.instagram.com/raquelgalvao.ia"
              target="_blank"
              rel="noreferrer"
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 bg-indigo-50/50 hover:bg-indigo-50 px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 border border-indigo-100/40"
            >
              <span>📲 Instagram @raquelgalvao.ia</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </header>

      {/* Main Grid Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-5 h-[calc(100vh-80px)] overflow-hidden">
        {/* Left column: History Sidebar */}
        <section className="lg:col-span-3 bg-white border border-gray-200 rounded-2xl flex flex-col overflow-hidden shadow-xs">
          {/* New Planning Action */}
          <div className="p-4 border-b border-gray-100">
            <button
              onClick={handleNewPlanning}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm py-3 px-4 rounded-xl shadow-md shadow-indigo-100 transition-all flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Novo Planejamento</span>
            </button>
          </div>

          {/* Session List */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            <h2 className="text-xs font-bold uppercase tracking-wider text-gray-400 px-3 py-1">
              Histórico de Aulas
            </h2>

            {savedPlannings.length === 0 ? (
              <div className="text-center py-8 px-4 text-gray-400 text-xs space-y-2.5">
                <FolderOpen className="w-8 h-8 mx-auto text-gray-300" />
                <p>Seus planejamentos salvos aparecerão aqui automaticamente.</p>
              </div>
            ) : (
              savedPlannings.map((p) => {
                const isActive = p.id === activeId;
                return (
                  <button
                    key={p.id}
                    onClick={() => handleSelectPlanning(p.id)}
                    className={`w-full text-left p-3 rounded-xl transition-all border flex items-start gap-2.5 relative group ${
                      isActive
                        ? "bg-indigo-50/40 border-indigo-100 text-indigo-950 font-medium"
                        : "bg-white border-transparent text-gray-700 hover:bg-gray-50 hover:border-gray-100"
                    }`}
                  >
                    <div className="mt-0.5 p-1.5 rounded-lg bg-slate-50 border border-slate-100 text-gray-500 shrink-0">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0 pr-6">
                      <p className="text-xs font-semibold truncate text-gray-900">
                        {p.title}
                      </p>
                      <span className="inline-block text-[10px] text-gray-500 mt-1">
                        {p.discipline} • {p.createdAt}
                      </span>
                    </div>

                    <button
                      onClick={(e) => handleDeletePlanning(e, p.id)}
                      className="absolute right-2 top-3 p-1 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all"
                      title="Excluir"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </button>
                );
              })
            )}
          </div>

          {/* Guidelines Mini Card */}
          <div className="p-4 bg-slate-50 border-t border-gray-100 text-xs text-gray-500 space-y-2">
            <h3 className="font-bold text-gray-700 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              Desenho Universal (DUA)
            </h3>
            <p className="leading-snug text-[11px]">
              Toda adaptação visa remover barreiras de representação, expressão ou engajamento sem diminuir a exigência cognitiva.
            </p>
          </div>
        </section>

        {/* Center column: Interactive Pedagogic Chat */}
        <section className="lg:col-span-5 bg-white border border-gray-200 rounded-2xl flex flex-col overflow-hidden shadow-xs relative">
          {/* Active Chat Header */}
          <div className="px-5 py-3.5 border-b border-gray-100 bg-white flex items-center gap-3 shrink-0">
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-full flex items-center justify-center text-white shadow-md font-bold">
                EI
              </div>
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
            </div>
            <div>
              <h2 className="text-sm font-bold text-gray-900 leading-none">EducaInclusiva</h2>
              <p className="text-[11px] text-gray-500 mt-1 flex items-center gap-1">
                <span>Ativo</span> • <span>Especialista em Inclusão BNCC</span>
              </p>
            </div>
          </div>

          {/* Connection Error Banner */}
          {errorBanner && (
            <div className="m-3 p-3.5 bg-red-50 border border-red-200 text-xs text-red-800 rounded-xl flex items-center justify-between gap-2 shrink-0 animate-fadeIn">
              <div className="flex items-start gap-2">
                <span className="font-bold">⚠️ Atenção:</span>
                <p className="leading-relaxed">{errorBanner}</p>
              </div>
              <button 
                onClick={() => sendMessage("Repetir última pergunta")}
                className="shrink-0 p-1 bg-white hover:bg-red-100 rounded border border-red-200 transition-all text-red-700 font-bold flex items-center gap-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Tentar</span>
              </button>
            </div>
          )}

          {/* Message History area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/40">
            {messages.length === 0 ? (
              <div className="text-center py-20 px-4 text-gray-400 space-y-3.5">
                <HelpCircle className="w-10 h-10 mx-auto text-gray-300" />
                <p className="text-xs">Inicie um novo planejamento para conversar.</p>
              </div>
            ) : (
              messages.map((m) => {
                const isAssistant = m.role === "assistant";
                return (
                  <div
                    key={m.id}
                    className={`flex ${isAssistant ? "justify-start" : "justify-end"} animate-fadeIn`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl p-4 text-sm shadow-xs ${
                        isAssistant
                          ? "bg-white border border-gray-100 text-gray-800 rounded-tl-none leading-relaxed"
                          : "bg-indigo-600 text-white rounded-tr-none"
                      }`}
                    >
                      <div className="whitespace-pre-line leading-relaxed">
                        {m.content}
                      </div>
                      <span
                        className={`block text-[9px] mt-2 text-right ${
                          isAssistant ? "text-gray-400" : "text-indigo-200"
                        }`}
                      >
                        {m.timestamp}
                      </span>
                    </div>
                  </div>
                );
              })
            )}

            {/* AI Typing Indicator */}
            {loading && (
              <div className="flex justify-start animate-pulse">
                <div className="bg-white border border-gray-100 rounded-2xl p-4 text-sm rounded-tl-none flex items-center gap-2">
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce delay-75"></div>
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce delay-150"></div>
                  <span className="text-xs text-gray-500 font-medium ml-1">EducaInclusiva está elaborando...</span>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Reply suggestion chips */}
          {suggestions.length > 0 && !loading && (
            <div className="px-4 py-2 bg-slate-50 border-t border-gray-100 flex items-center gap-2 overflow-x-auto whitespace-nowrap shrink-0 scrollbar-none scroll-smooth">
              <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Sugestões:</span>
              {suggestions.map((sug, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSuggestionClick(sug)}
                  className="bg-white hover:bg-indigo-50 border border-gray-200 hover:border-indigo-200 text-indigo-700 font-semibold px-3 py-1.5 rounded-full text-xs shadow-xs transition-all shrink-0 flex items-center gap-1.5 cursor-pointer"
                >
                  <span>{sug}</span>
                  <ChevronRight className="w-3 h-3 text-indigo-400" />
                </button>
              ))}
            </div>
          )}

          {/* Message Input Action bar */}
          <div className="p-4 border-t border-gray-100 bg-white shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                sendMessage(input);
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Escreva sua resposta ou dúvida pedagógica..."
                className="flex-1 bg-slate-50 border border-gray-200 focus:border-indigo-500 focus:bg-white text-sm px-4 py-3 rounded-xl focus:outline-none transition-all"
                disabled={loading}
              />
              <button
                type="submit"
                disabled={!input.trim() || loading}
                className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300 text-white p-3 rounded-xl shadow-md shadow-indigo-100 transition-all shrink-0 flex items-center justify-center cursor-pointer"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </section>

        {/* Right column: Dynamic Multi-tab Board */}
        <section className="lg:col-span-4 bg-white border border-gray-200 rounded-2xl flex flex-col overflow-hidden shadow-xs">
          {/* Tab Selection Headers */}
          <div className="border-b border-gray-100 bg-gray-50 p-2 flex items-center gap-1 shrink-0">
            <button
              onClick={() => setCurrentTab("memory")}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                currentTab === "memory"
                  ? "bg-white text-indigo-950 shadow-xs border border-gray-200/50"
                  : "text-gray-500 hover:text-indigo-600 hover:bg-gray-100"
              }`}
            >
              <ClipboardList className="w-4 h-4" />
              <span>Memória</span>
            </button>

            <button
              onClick={() => setCurrentTab("document")}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 relative ${
                currentTab === "document"
                  ? "bg-white text-indigo-950 shadow-xs border border-gray-200/50"
                  : "text-gray-500 hover:text-indigo-600 hover:bg-gray-100"
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Material</span>
              {material.type !== "none" && material.type !== "dashboard" && (
                <span className="absolute top-1 right-2 w-2 h-2 bg-indigo-500 rounded-full"></span>
              )}
            </button>

            <button
              onClick={() => setCurrentTab("dashboard")}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 relative ${
                currentTab === "dashboard"
                  ? "bg-white text-indigo-950 shadow-xs border border-gray-200/50"
                  : "text-gray-500 hover:text-indigo-600 hover:bg-gray-100"
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>Dashboard</span>
              {material.type === "dashboard" && (
                <span className="absolute top-1 right-2 w-2 h-2 bg-indigo-500 rounded-full animate-ping"></span>
              )}
            </button>
          </div>

          {/* Tab Contents Frame */}
          <div className="flex-1 overflow-y-auto p-4">
            {currentTab === "memory" && (
              <WorkingMemoryView memory={workingMemory} />
            )}

            {currentTab === "document" && (
              <>
                {material.type !== "none" && material.type !== "dashboard" ? (
                  <MaterialViewer material={material} />
                ) : (
                  <div className="text-center py-20 px-6 text-gray-400 space-y-4">
                    <BookOpen className="w-12 h-12 mx-auto text-indigo-200" />
                    <div>
                      <h4 className="font-bold text-gray-800 text-sm">Nenhum Material Gerado Ainda</h4>
                      <p className="text-xs text-gray-500 mt-1 max-w-xs mx-auto">
                        Converse com o EducaInclusiva no chat para preencher os dados. Solicite "Gere o plano de aula" ou "Gere a adaptação" quando estiver pronto(a).
                      </p>
                    </div>

                    {/* Quick Template Starters for instant demonstration */}
                    <div className="border-t border-gray-100 pt-5 mt-5">
                      <h5 className="text-[10px] uppercase font-bold text-indigo-500 tracking-wider mb-3">Atalhos de Demonstração Rápida:</h5>
                      <div className="flex flex-col gap-2.5">
                        <button
                          onClick={() => handleLoadStarterTemplate("Ciências", "4º Ano", "Cadeias Alimentares", "Aluna Autista (TEA)")}
                          className="text-left bg-indigo-50/30 hover:bg-indigo-50 border border-indigo-100/50 hover:border-indigo-200 p-2.5 rounded-xl transition-all cursor-pointer"
                        >
                          <p className="text-xs font-bold text-indigo-950">Ciências • 4º Ano • TEA</p>
                          <p className="text-[10px] text-indigo-600 mt-0.5">Adaptar plano sobre Cadeia Alimentar</p>
                        </button>

                        <button
                          onClick={() => handleLoadStarterTemplate("Matemática", "5º Ano", "Frações com Pizza", "Estudante com TDAH")}
                          className="text-left bg-indigo-50/30 hover:bg-indigo-50 border border-indigo-100/50 hover:border-indigo-200 p-2.5 rounded-xl transition-all cursor-pointer"
                        >
                          <p className="text-xs font-bold text-indigo-950">Matemática • 5º Ano • TDAH</p>
                          <p className="text-[10px] text-indigo-600 mt-0.5">Adaptar aula prática com material concreto</p>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}

            {currentTab === "dashboard" && (
              <div className="h-full">
                {material.type === "dashboard" || material.dashboardData ? (
                  <DashboardView
                    dataString={material.dashboardData}
                    onUpdateData={handleUpdateDashboardData}
                  />
                ) : (
                  <div className="text-center py-20 px-6 text-gray-400 space-y-4">
                    <GraduationCap className="w-12 h-12 mx-auto text-indigo-200 animate-pulse" />
                    <div>
                      <h4 className="font-bold text-gray-800 text-sm">Dashboard de Acompanhamento</h4>
                      <p className="text-xs text-gray-500 mt-1 max-w-xs mx-auto">
                        O EducaInclusiva pode criar um painel interativo de acessibilidade com metas de progresso do estudante.
                      </p>
                    </div>

                    <button
                      onClick={() => sendMessage("Gere um dashboard de acessibilidade para o meu planejamento")}
                      className="bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-bold text-xs py-2 px-4 rounded-xl transition-all inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>Gerar Exemplo de Dashboard</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
