export interface WorkingMemory {
  disciplina: string;
  ano: string;
  tema: string;
  objetivo: string;
  perfisInclusivos: string;
  recursos: string;
}

export interface MaterialGerado {
  type: "lesson_plan" | "sequence" | "evaluation" | "adaptation" | "dashboard" | "none";
  title: string;
  markdown: string;
  dashboardData?: string; // stringified JSON
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export interface SavedPlanning {
  id: string;
  title: string;
  discipline: string;
  createdAt: string;
  messages: Message[];
  workingMemory: WorkingMemory;
  material: MaterialGerado;
}

export interface DashboardInfo {
  titulo: string;
  aluno: string;
  metas: {
    id: string;
    meta: string;
    concluido: boolean;
    categoria: string;
  }[];
  desempenho: {
    eixo: string;
    valor: number;
    esperado: number;
  }[];
  sugestoes: string[];
}
