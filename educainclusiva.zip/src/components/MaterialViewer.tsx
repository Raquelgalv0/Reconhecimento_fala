import { useState, ReactNode } from "react";
import { Copy, Check, Download, FileText, Share2 } from "lucide-react";
import { MaterialGerado } from "../types";

interface MaterialViewerProps {
  material: MaterialGerado;
}

export default function MaterialViewer({ material }: MaterialViewerProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(material.markdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([material.markdown], { type: "text/markdown;charset=utf-8" });
    element.href = URL.createObjectURL(file);
    element.download = `${material.title.toLowerCase().replace(/\s+/g, "_") || "planejamento"}.md`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Safe and super clean custom markdown formatter for React 19 (no package mismatches)
  const formatMarkdown = (md: string) => {
    if (!md) return <p className="text-gray-400 italic">Nenhum conteúdo gerado.</p>;

    const lines = md.split("\n");
    let inList = false;
    const elements: ReactNode[] = [];

    const parseInlineStyles = (text: string) => {
      // Very robust bold text formatter **bold**
      const parts = text.split(/\*\*([\s\S]*?)\*\*/g);
      return parts.map((part, i) => {
        if (i % 2 === 1) {
          return <strong key={i} className="font-extrabold text-indigo-950 bg-indigo-50/50 px-1 rounded">{part}</strong>;
        }
        return part;
      });
    };

    lines.forEach((line, index) => {
      const trimmed = line.trim();

      // Heading 1
      if (trimmed.startsWith("# ")) {
        elements.push(
          <h1 key={`h1-${index}`} className="text-2xl font-black text-indigo-950 mt-6 mb-4 border-b border-indigo-100 pb-2 font-sans tracking-tight">
            {parseInlineStyles(trimmed.slice(2))}
          </h1>
        );
        inList = false;
      }
      // Heading 2
      else if (trimmed.startsWith("## ")) {
        elements.push(
          <h2 key={`h2-${index}`} className="text-xl font-bold text-indigo-900 mt-5 mb-3 font-sans tracking-tight flex items-center gap-2">
            <span className="w-1 h-5 bg-indigo-500 rounded-full inline-block"></span>
            {parseInlineStyles(trimmed.slice(3))}
          </h2>
        );
        inList = false;
      }
      // Heading 3
      else if (trimmed.startsWith("### ")) {
        elements.push(
          <h3 key={`h3-${index}`} className="text-lg font-bold text-indigo-800 mt-4 mb-2 font-sans">
            {parseInlineStyles(trimmed.slice(4))}
          </h3>
        );
        inList = false;
      }
      // List items
      else if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
        elements.push(
          <li key={`li-${index}`} className="ml-5 list-disc text-sm text-gray-700 mb-1.5 leading-relaxed pl-1">
            {parseInlineStyles(trimmed.slice(2))}
          </li>
        );
        inList = true;
      }
      // Blockquote
      else if (trimmed.startsWith("> ")) {
        elements.push(
          <blockquote key={`quote-${index}`} className="border-l-4 border-amber-400 bg-amber-50/40 p-3 rounded-r-lg my-3 text-xs text-amber-900 leading-relaxed font-medium">
            {parseInlineStyles(trimmed.slice(2))}
          </blockquote>
        );
        inList = false;
      }
      // Empty lines
      else if (trimmed === "") {
        inList = false;
      }
      // Standard Paragraph
      else {
        elements.push(
          <p key={`p-${index}`} className="text-sm text-gray-700 leading-relaxed mb-3">
            {parseInlineStyles(trimmed)}
          </p>
        );
        inList = false;
      }
    });

    return <div className="space-y-1">{elements}</div>;
  };

  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-xs animate-fadeIn">
      {/* Top action bar */}
      <div className="bg-gray-50 border-b border-gray-200 px-5 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-indigo-600" />
          <h3 className="text-sm font-bold text-gray-900 truncate max-w-xs md:max-w-md">
            {material.title || "Material Pedagógico"}
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg bg-white border border-gray-200 text-gray-600 hover:text-indigo-600 hover:border-indigo-200 transition-all text-xs flex items-center gap-1 font-semibold"
            title="Copiar para área de transferência"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-500" />
                <span className="text-emerald-600">Copiado</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copiar</span>
              </>
            )}
          </button>

          <button
            onClick={handleDownload}
            className="p-1.5 rounded-lg bg-white border border-gray-200 text-gray-600 hover:text-indigo-600 hover:border-indigo-200 transition-all text-xs flex items-center gap-1 font-semibold"
            title="Baixar em Markdown"
          >
            <Download className="w-4 h-4" />
            <span>Baixar .MD</span>
          </button>
        </div>
      </div>

      {/* Main Document Frame */}
      <div className="p-6 md:p-8 max-h-[650px] overflow-y-auto bg-slate-50/30 font-sans selection:bg-indigo-100">
        <div className="max-w-3xl mx-auto bg-white border border-gray-100 p-6 md:p-8 rounded-xl shadow-xs">
          {/* Document Header Decors */}
          <div className="flex justify-between items-center border-b border-gray-100 pb-4 mb-6">
            <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-500">
              EducaInclusiva • Material Oficial
            </span>
            <span className="text-[10px] text-gray-400 font-mono">
              Código: {Math.random().toString(36).substr(2, 6).toUpperCase()}
            </span>
          </div>

          {/* Renders formatted document */}
          <div className="prose prose-indigo max-w-none">
            {formatMarkdown(material.markdown)}
          </div>
        </div>
      </div>
    </div>
  );
}
