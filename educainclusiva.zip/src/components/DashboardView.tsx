import { useState, useEffect } from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
} from "recharts";
import { DashboardInfo } from "../types";
import { CheckCircle, AlertTriangle, Lightbulb, Users, BarChart3, TrendingUp, CheckSquare, Square } from "lucide-react";

interface DashboardViewProps {
  dataString?: string;
  onUpdateData?: (updatedData: string) => void;
}

export default function DashboardView({ dataString, onUpdateData }: DashboardViewProps) {
  const [dashboard, setDashboard] = useState<DashboardInfo | null>(null);

  // Parse data and fallback to beautiful default educational dashboard if empty
  useEffect(() => {
    if (dataString) {
      try {
        const parsed = JSON.parse(dataString);
        setDashboard(parsed);
      } catch (e) {
        console.error("Failed to parse dashboard data, using defaults", e);
        setDefaultDashboard();
      }
    } else {
      setDefaultDashboard();
    }
  }, [dataString]);

  const setDefaultDashboard = () => {
    setDashboard({
      titulo: "Painel de Acompanhamento Inclusivo - Adaptação Curricular",
      aluno: "Estudante com TEA / TDAH",
      metas: [
        { id: "1", meta: "Redução de estímulos visuais na folha de atividade", concluido: true, categoria: "Sensorial" },
        { id: "2", meta: "Fracionamento das tarefas em 3 blocos curtos com pausas", concluido: false, categoria: "Cognitivo" },
        { id: "3", meta: "Utilização de blocos lógicos táteis (material concreto)", concluido: true, categoria: "Acessibilidade" },
        { id: "4", meta: "Uso de cartões de comunicação alternativa para respostas", concluido: false, categoria: "Comunicação" },
      ],
      desempenho: [
        { eixo: "Semana 1", valor: 45, esperado: 70 },
        { eixo: "Semana 2", valor: 60, esperado: 70 },
        { eixo: "Semana 3", valor: 85, esperado: 75 },
        { eixo: "Semana 4", valor: 90, esperado: 75 },
      ],
      sugestoes: [
        "Mantenha feedbacks positivos imediatos a cada pequena tarefa concluída para incentivar o engajamento.",
        "Se notar sinais de fadiga sensorial (agitação, tampar ouvidos), direcione o aluno ao 'Espaço de Descompressão'.",
        "Ofereça escolha de formato para avaliação: oral, escrita adaptada ou representação em desenho.",
      ],
    });
  };

  if (!dashboard) return null;

  const toggleMeta = (metaId: string) => {
    const updatedMetas = dashboard.metas.map((m) =>
      m.id === metaId ? { ...m, concluido: !m.concluido } : m
    );
    const updated = { ...dashboard, metas: updatedMetas };
    setDashboard(updated);
    if (onUpdateData) {
      onUpdateData(JSON.stringify(updated));
    }
  };

  const completedCount = dashboard.metas.filter((m) => m.concluido).length;
  const totalCount = dashboard.metas.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div id="dashboard-container" className="space-y-6 text-gray-800 animate-fadeIn p-2">
      {/* Header Info */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="bg-blue-600 text-white text-xs font-semibold px-2.5 py-1 rounded-full uppercase tracking-wider">
            Dashboard HTML Pedagógico
          </span>
          <h2 className="text-xl font-bold text-gray-900 mt-2 font-sans">{dashboard.titulo}</h2>
          <p className="text-sm text-gray-600 mt-1 flex items-center gap-1.5">
            <Users className="w-4 h-4 text-blue-500" />
            Perfil do Estudante Alvo: <strong className="text-blue-700">{dashboard.aluno}</strong>
          </p>
        </div>
        <div className="bg-white px-4 py-3 rounded-lg border border-blue-200 text-center shadow-xs">
          <div className="text-2xl font-extrabold text-blue-600">{progressPercent}%</div>
          <div className="text-xs text-gray-500 font-medium uppercase tracking-wider">Metas Concluídas</div>
        </div>
      </div>

      {/* Mini Stats Bento */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-xs flex items-center gap-3.5">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-gray-900">{completedCount} de {totalCount}</div>
            <div className="text-xs text-gray-500 font-medium">Metas de Acessibilidade</div>
          </div>
        </div>

        <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-xs flex items-center gap-3.5">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-gray-900">Média 87%</div>
            <div className="text-xs text-gray-500 font-medium">Nível de Engajamento</div>
          </div>
        </div>

        <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-xs flex items-center gap-3.5">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-gray-900">Baixo Risco</div>
            <div className="text-xs text-gray-500 font-medium">Grau de Sobrecarga Cognitiva</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Goals Checklist */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 lg:col-span-6 shadow-xs">
          <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-4">
            <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <CheckSquare className="w-5 h-5 text-indigo-600" />
              Metas de Adaptação (Interativo)
            </h3>
            <span className="text-xs text-gray-500">Marque para concluir</span>
          </div>
          <div className="space-y-3">
            {dashboard.metas.map((meta) => (
              <button
                key={meta.id}
                onClick={() => toggleMeta(meta.id)}
                className={`w-full text-left p-3.5 rounded-lg border transition-all flex items-start gap-3 ${
                  meta.concluido
                    ? "bg-emerald-50/40 border-emerald-100 text-gray-600 line-through decoration-emerald-200"
                    : "bg-gray-50/50 border-gray-100 text-gray-800 hover:bg-gray-50"
                }`}
              >
                <div className="mt-0.5 shrink-0">
                  {meta.concluido ? (
                    <CheckCircle className="w-5 h-5 text-emerald-500 fill-emerald-100" />
                  ) : (
                    <div className="w-5 h-5 rounded border border-gray-300 bg-white" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium leading-snug">{meta.meta}</p>
                  <span
                    className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-full mt-1.5 ${
                      meta.categoria === "Sensorial"
                        ? "bg-purple-100 text-purple-700"
                        : meta.categoria === "Cognitivo"
                        ? "bg-sky-100 text-sky-700"
                        : meta.categoria === "Acessibilidade"
                        ? "bg-teal-100 text-teal-700"
                        : "bg-amber-100 text-amber-700"
                    }`}
                  >
                    {meta.categoria}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Right Col: Progress Charts */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 lg:col-span-6 shadow-xs">
          <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-4">
            <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-600" />
              Evolução e Progresso do Aluno
            </h3>
            <span className="text-xs text-gray-500">Com vs Sem Adaptações</span>
          </div>

          <div className="h-60 w-full mt-4 text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={dashboard.desempenho}
                margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="eixo" stroke="#6b7280" />
                <YAxis stroke="#6b7280" domain={[0, 100]} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#ffffff", borderRadius: "8px", border: "1px solid #e5e7eb" }}
                />
                <Legend iconType="circle" wrapperStyle={{ paddingTop: "10px" }} />
                <Bar name="Com Adaptação (%)" dataKey="valor" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                <Bar name="Sem Adaptação (Previsto %)" dataKey="esperado" fill="#cbd5e1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recommendations & Ideas */}
      <div className="bg-amber-50/50 border border-amber-100 rounded-xl p-5">
        <h4 className="text-sm font-bold text-amber-900 flex items-center gap-1.5">
          <Lightbulb className="w-5 h-5 text-amber-500" />
          Orientações Práticas do EducaInclusiva
        </h4>
        <ul className="mt-3 space-y-2.5">
          {dashboard.sugestoes.map((sug, idx) => (
            <li key={idx} className="text-xs text-amber-800 flex items-start gap-2">
              <span className="text-amber-500 font-bold mt-0.5">•</span>
              <span>{sug}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
