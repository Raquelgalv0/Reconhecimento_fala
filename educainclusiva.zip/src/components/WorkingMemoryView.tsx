import { WorkingMemory } from "../types";
import { BookOpen, GraduationCap, ClipboardList, Target, Eye, Wrench, CheckCircle, HelpCircle } from "lucide-react";

interface WorkingMemoryViewProps {
  memory: WorkingMemory;
}

export default function WorkingMemoryView({ memory }: WorkingMemoryViewProps) {
  const blocks = [
    {
      key: "disciplina",
      label: "Componente Curricular",
      value: memory.disciplina,
      icon: BookOpen,
      color: "border-blue-200 bg-blue-50/20 text-blue-700",
      iconColor: "text-blue-500",
      desc: "A matéria ou disciplina que está sendo planejada.",
    },
    {
      key: "ano",
      label: "Ano / Série Escolar",
      value: memory.ano,
      icon: GraduationCap,
      color: "border-purple-200 bg-purple-50/20 text-purple-700",
      iconColor: "text-purple-500",
      desc: "Nível de ensino ou série escolar dos estudantes.",
    },
    {
      key: "tema",
      label: "Tema Central",
      value: memory.tema,
      icon: ClipboardList,
      color: "border-sky-200 bg-sky-50/20 text-sky-700",
      iconColor: "text-sky-500",
      desc: "O assunto específico ou conteúdo programático.",
    },
    {
      key: "objetivo",
      label: "Objetivo de Aprendizagem (BNCC)",
      value: memory.objetivo,
      icon: Target,
      color: "border-emerald-200 bg-emerald-50/20 text-emerald-700",
      iconColor: "text-emerald-500",
      desc: "Habilidades BNCC ou objetivos a atingir.",
    },
    {
      key: "perfisInclusivos",
      label: "Perfis e Adaptações de Inclusão",
      value: memory.perfisInclusivos,
      icon: Eye,
      color: "border-pink-200 bg-pink-50/20 text-pink-700",
      iconColor: "text-pink-500",
      desc: "Necessidades especiais, transtornos ou apoios.",
    },
    {
      key: "recursos",
      label: "Recursos de Apoio & Acessibilidade",
      value: memory.recursos,
      icon: Wrench,
      color: "border-amber-200 bg-amber-50/20 text-amber-700",
      iconColor: "text-amber-500",
      desc: "Tecnologia assistiva, materiais concretos ou digitais.",
    },
  ];

  return (
    <div className="space-y-4">
      <div className="border-b border-gray-100 pb-3">
        <h3 className="text-sm font-bold text-gray-900">Quadro de Planejamento Ativo</h3>
        <p className="text-xs text-gray-500 mt-1">
          Acompanhe em tempo real as informações coletadas pelo assistente EducaInclusiva durante a conversa.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {blocks.map((b) => {
          const Icon = b.icon;
          const isFilled = !!b.value && b.value !== "Ainda não definido" && b.value !== "Nenhum";

          return (
            <div
              key={b.key}
              className={`p-4 rounded-xl border transition-all duration-300 ${
                isFilled
                  ? `${b.color} shadow-xs border-opacity-100`
                  : "bg-gray-50/40 border-gray-100 text-gray-400"
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Icon className={`w-4 h-4 ${isFilled ? b.iconColor : "text-gray-400"}`} />
                  <span className="text-xs font-bold uppercase tracking-wider">{b.label}</span>
                </div>
                <div>
                  {isFilled ? (
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                  ) : (
                    <HelpCircle className="w-4 h-4 text-gray-300" />
                  )}
                </div>
              </div>

              <div className="mt-1">
                {isFilled ? (
                  <p className="text-sm font-semibold text-gray-950 leading-relaxed break-words">
                    {b.value}
                  </p>
                ) : (
                  <p className="text-xs italic text-gray-400">
                    Aguardando na conversa...
                  </p>
                )}
              </div>
              <p className="text-[10px] text-gray-400 mt-1.5 leading-normal">{b.desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
